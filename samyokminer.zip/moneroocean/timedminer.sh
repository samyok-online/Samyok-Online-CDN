#!/bin/sh

# Wanted trigger timeout in milliseconds.
IDLE_TIME=$((5*1000))

# Sequence to execute when timeout triggers.
trigger_cmd() {
    echo "Triggered action $(date)"
}

sleep_time=$IDLE_TIME
triggered=false

# ceil() instead of floor()
while sleep $(((sleep_time+999)/1000)); do
    idle=$(xprintidle)
    if [ $idle -ge $IDLE_TIME ]; then
        if ! $triggered; then
	    echo "[$(date)] Started xmrig"; 
	    ~/moneroocean/miner.sh &
            triggered=true
            sleep_time=$IDLE_TIME
        fi
    else
        triggered=false
        # Give 100 ms buffer to avoid frantic loops shortly before triggers.
	if pkill xmrig; then echo "\n[$(date)] Killed xmrig\n\n"; fi
        sleep_time=$((IDLE_TIME-idle+100))
    fi
done
